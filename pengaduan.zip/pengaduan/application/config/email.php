<?php

$config['protocol'] = 'smtp';
$config['smtp_host'] = 'mail.snippets-code.com';
$config['smtp_user'] = 'dwi@gmail.com';
$config['smtp_pass'] = '081364456585!aA';
$config['smtp_port'] = '587';
$config['mailtype'] = 'html';
$config['priority'] = '1';
$config['charset'] = 'utf-8';
