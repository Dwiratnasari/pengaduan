<?php

$config['error_prefix'] = ' ';
$config['error_suffix'] = '<br />';