<?php

class Pengaturan_model extends CIF_model
{
    public $_table = 'pengaturan';
    public $_primary_keys = array('key');


}
