<?php

class Faqs_model extends CIF_model
{
    public $_table = 'faqs';
    public $_primary_keys = array('faq_id');


}
