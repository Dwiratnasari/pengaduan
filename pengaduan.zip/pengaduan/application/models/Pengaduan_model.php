<?php

class Pengaduan_model extends CIF_model
{
    public $_table = 'pengaduan';
    public $_primary_keys = array('pengaduan_id');

}
