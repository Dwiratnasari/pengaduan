<?php

class Halaman_model extends CIF_model
{
    public $_table = 'halaman';
    public $_primary_keys = array('halaman_id');


}
