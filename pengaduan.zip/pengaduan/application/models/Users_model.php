<?php

class Users_model extends CIF_model
{
    public $_table = 'users';
    public $_primary_keys = array('user_id');


}
